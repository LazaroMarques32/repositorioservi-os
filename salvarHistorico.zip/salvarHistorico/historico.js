const express = require("express");
const cors = require("cors");
const { GoogleGenerativeAI } = require("@google/generative-ai");
const fs = require("fs");

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Configuração da API Gemini
const apiKey = process.env.GEMINI_API_KEY || "AIzaSyCjsBc1-XeJdfwfC5l_V7GJP1BTPi5dFfA";
const genAI = new GoogleGenerativeAI(apiKey);

const model = genAI.getGenerativeModel({
  model: "gemini-1.5-flash",
});

const generationConfig = {
  temperature: 1,
  topP: 0.95,
  topK: 40,
  maxOutputTokens: 8192,
  responseMimeType: "text/plain",
};

// Carrega o histórico (opcional para persistência de dados)
const HISTORY_FILE = "historico.json";

function loadHistory() {
  if (fs.existsSync(HISTORY_FILE)) {
    return JSON.parse(fs.readFileSync(HISTORY_FILE, "utf-8"));
  }
  return [];
}

function saveHistory(history) {
  fs.writeFileSync(HISTORY_FILE, JSON.stringify(history, null, 2));
}

// Endpoint principal para o chatbot
app.post("/chat", async (req, res) => {
  const { message } = req.body;

  if (!message) {
    return res.status(400).json({ error: "Mensagem é obrigatória." });
  }

  try {
    const history = loadHistory();
    const chatSession = model.startChat({ generationConfig, history });

    // Envia mensagem para o modelo
    const result = await chatSession.sendMessage(message);
    const botResponse = result.response.text();

    // Atualiza e salva o histórico
    history.push({ role: "user", parts: [{ text: message }] });
    history.push({ role: "model", parts: [{ text: botResponse }] });
    saveHistory(history);

    res.json({ response: botResponse });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Erro ao gerar resposta." });
  }
});

// Inicia o servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});

/*
Este código é um chatbot simples que usa a API Google Gemini para gerar respostas 
baseadas nas mensagens anteriores do usuário. O histórico da conversa é salvo em um arquivo JSON para 
permitir que a conversa continue quando o programa for reaberto.

Decisões de Design e Implementação:
1. API Gemini: A API Gemini foi escolhida por ser eficiente e gerar respostas de 
   boa qualidade para o chatbot. Além de ser a IA que mais trabalhamos durante a matéria de Serviços em Nuvem.

2. Armazenamento do Histórico: O histórico é armazenado em um arquivo JSON (historico.json) 
   para ser carregado e salvo durante a interação, facilitando o acesso a conversa.

3. Estrutura do Histórico: O histórico é armazenado como um array de objetos, cada um com 
   o role (usuário e modelo) e a mensagem.

4. Interação no Terminal: O usuário interage com o chatbot por meio do terminal, 
   onde pode digitar mensagens e usar os comandos "sair" e "nova" para controlar a conversa.

5. Logs dos Erros: O código garante que erros sejam capturados e logados.

PS: O bot parou de funcionar por conta de problemas com o Google Cloud, mas o histórico das minhas conversas passadas com o chatbot foram armazenadas  com sucesso no arquivo json.
*/
