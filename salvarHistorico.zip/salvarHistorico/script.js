document.addEventListener("DOMContentLoaded", () => {
    const chatHistory = document.getElementById("chat-history");
    const userInput = document.getElementById("user-input");
    const sendBtn = document.getElementById("send-btn");
  
    // Função para adicionar mensagens ao histórico na interface
    const addMessageToHistory = (role, text) => {
      const message = document.createElement("div");
      message.className = `message ${role}`;
      message.textContent = text;
      chatHistory.appendChild(message);
      chatHistory.scrollTop = chatHistory.scrollHeight; // Rola para o final
    };
  
    // Função para enviar mensagem para o backend
    const sendMessage = async (message) => {
      addMessageToHistory("user", message); // Adiciona a mensagem do usuário na interface
  
      try {
        const response = await fetch("http://localhost:3000/chat", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ message }), // Envia a mensagem como JSON
        });
  
        if (response.ok) {
          const data = await response.json();
          addMessageToHistory("bot", data.response); // Adiciona a resposta do bot na interface
        } else {
          throw new Error("Erro ao se comunicar com o servidor.");
        }
      } catch (err) {
        addMessageToHistory("bot", "Erro: Não foi possível obter uma resposta.");
        console.error(err);
      }
    };
  
    // Eventos de clique e Enter para enviar mensagens
    sendBtn.addEventListener("click", () => {
      const message = userInput.value.trim();
      if (message) {
        sendMessage(message);
        userInput.value = ""; // Limpa o campo de entrada
      }
    });
  
    userInput.addEventListener("keypress", (event) => {
      if (event.key === "Enter") {
        sendBtn.click();
      }
    });
  });
  